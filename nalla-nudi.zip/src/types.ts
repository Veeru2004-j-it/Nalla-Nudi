export type Subject = "Science" | "Mathematics" | "Commerce" | "General";

export interface Word {
  id: number;
  englishWord: string;
  kannadaMeaning: string;
  explanation: string;
  subject: Subject;
  exampleSentence: string;
  difficulty?: "Beginner" | "Intermediate" | "Advanced";
}

export interface SearchHistoryItem {
  id: number;
  word: string;
  timestamp: number;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}
