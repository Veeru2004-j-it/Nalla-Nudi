import { GoogleGenAI, Type } from "@google/genai";
import { Word, Subject } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export const aiService = {
  async getAiExplanation(word: string): Promise<Partial<Word> | null> {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Explain the technical term "${word}" for a Kannada-medium student.
        Return a JSON object with:
        - englishWord: string
        - kannadaMeaning: string (Short)
        - explanation: string (Simple Kannada, 1-2 sentences)
        - subject: string (Science, Mathematics, or Commerce)
        - exampleSentence: string (Simple English)
        Ensure the explanation is very simple and easy to understand.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              englishWord: { type: Type.STRING },
              kannadaMeaning: { type: Type.STRING },
              explanation: { type: Type.STRING },
              subject: { type: Type.STRING },
              exampleSentence: { type: Type.STRING },
            },
            required: ["englishWord", "kannadaMeaning", "explanation", "subject", "exampleSentence"],
          },
        },
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("AI Explanation Error:", error);
      return null;
    }
  },

  async generateQuiz(words: Word[]): Promise<any[]> {
    try {
      const wordList = words.map(w => w.englishWord).join(", ");
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Create 5 multiple choice questions for these terms: ${wordList}.
        Each question should ask for the Kannada meaning or a simple concept.
        Return a JSON array of objects with:
        - question: string
        - options: string[] (Exactly 4 options)
        - correctIndex: number (0-3)
        - explanation: string (Why it's correct, in Kannada)`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctIndex: { type: Type.NUMBER },
                explanation: { type: Type.STRING },
              },
              required: ["question", "options", "correctIndex", "explanation"],
            },
          },
        },
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Quiz Generation Error:", error);
      return [];
    }
  },

  async smartSearchSuggestion(query: string, availableWords: string[]): Promise<string[]> {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Given the user search query "${query}", suggest 3 relevant technical terms from this list if possible, or common technical terms in Science/Math/Commerce.
        List: ${availableWords.slice(0, 50).join(", ")}
        Return a JSON array of strings.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
      });
      return JSON.parse(response.text);
    } catch (error) {
       return [];
    }
  }
};
