import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { Send, User, Bot, Sparkles, X } from 'lucide-react';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

interface Message {
  role: 'user' | 'bot';
  text: string;
}

export function AIChat({ onClose }: { onClose: () => void }) {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'bot', text: 'ನಮಸ್ಕಾರ! ನಾನು ನಿಮ್ಮ ಶೈಕ್ಷಣಿಕ ಸಹಾಯಕ. ವಿಜ್ಞಾನ, ಗಣಿತ ಅಥವಾ ವಾಣಿಜ್ಯದ ಯಾವುದೇ ಪದದ ಬಗ್ಗೆ ಕೇಳಿ ನಾನು ವಿವರಿಸುತ್ತೇನೆ.' }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    
    const userText = input;
    setInput("");
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: userText,
        config: {
          systemInstruction: "You are 'Nalla-Nudi assistant', a friendly tutor for Kannada-medium students. Explain English technical terms in simple Kannada. Keep explanations short and use examples."
        }
      });
      
      setMessages(prev => [...prev, { role: 'bot', text: response.text }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'bot', text: "ಕ್ಷಮಿಸಿ, ಏನೋ ದೋಷ ಸಂಭವಿಸಿದೆ. ನಂತರ ಪ್ರಯತ್ನಿಸಿ." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-black flex flex-col md:max-w-md md:mx-auto md:relative md:inset-auto md:h-[600px] md:rounded-[40px] md:shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-10 duration-500">
      <header className="p-6 bg-indigo-600 text-white flex justify-between items-center shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="font-bold">AI Assistant</h3>
            <p className="text-[10px] opacity-80 uppercase tracking-widest font-bold">Nalla-Nudi Guide</p>
          </div>
        </div>
        <button onClick={onClose} className="p-2 bg-white/10 rounded-xl hover:bg-white/20 transition-colors">
          <X size={20} />
        </button>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar scrolling-touch">
        {messages.map((m, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`flex gap-3 max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-xl shrink-0 flex items-center justify-center ${m.role === 'user' ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-600 dark:bg-gray-800'}`}>
                {m.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                m.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none' 
                  : 'bg-gray-50 dark:bg-gray-900 dark:text-gray-200 border border-gray-100 dark:border-gray-800 rounded-tl-none'
              }`}>
                {m.text}
              </div>
            </div>
          </motion.div>
        ))}
        {loading && (
          <div className="flex justify-start">
             <div className="flex gap-3">
                <div className="w-8 h-8 rounded-xl bg-gray-100 flex items-center justify-center text-gray-400">
                  <Bot size={16} />
                </div>
                <div className="p-4 bg-gray-50 rounded-2xl rounded-tl-none border border-gray-100 flex gap-1">
                   <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce" />
                   <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce [animation-delay:-0.15s]" />
                   <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce [animation-delay:-0.3s]" />
                </div>
             </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white dark:bg-black border-t border-gray-100 dark:border-gray-800 shrink-0">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Ask anything..."
            className="w-full bg-gray-100 dark:bg-gray-900 border-none rounded-2xl py-4 pl-4 pr-14 outline-none focus:ring-2 focus:ring-indigo-600 transition-all text-sm"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-xl disabled:opacity-50 transition-all active:scale-90"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
