import React from 'react';
import { motion } from 'motion/react';
import { UserStats } from '../hooks/useUserStats';
import { Award, Zap, BookOpen, Star, TrendingUp } from 'lucide-react';

export function Dashboard({ stats }: { stats: UserStats }) {
  const levelProgress = (stats.xp % 1000) / 10;

  return (
    <div className="space-y-6 px-4 py-6">
      {/* Level Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-indigo-600 rounded-[32px] p-6 text-white shadow-xl shadow-indigo-500/20 relative overflow-hidden"
      >
        <div className="relative z-10">
          <div className="flex justify-between items-center mb-4">
            <div>
              <p className="text-indigo-200 text-xs font-bold uppercase tracking-widest">Level</p>
              <h2 className="text-5xl font-black">{stats.level}</h2>
            </div>
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
              <Award size={32} />
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold">
              <span>{stats.xp} XP</span>
              <span>{(stats.level) * 1000} XP</span>
            </div>
            <div className="h-3 bg-white/20 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${levelProgress}%` }}
                className="h-full bg-white shadow-[0_0_15px_rgba(255,255,255,0.8)]"
              />
            </div>
          </div>
        </div>
        <div className="absolute -right-6 -bottom-6 opacity-10">
          <Award size={180} />
        </div>
      </motion.div>

      {/* Grid Stats */}
      <div className="grid grid-cols-2 gap-4">
        <StatCard 
          icon={<Zap className="text-orange-500" />} 
          label="Streak" 
          value={`${stats.streak} Days`} 
          sub="Daily goal met"
        />
        <StatCard 
          icon={<BookOpen className="text-blue-500" />} 
          label="Mastered" 
          value={stats.wordsLearned.toString()} 
          sub="Terms learned"
        />
      </div>

      {/* Badges Section */}
      <div className="bg-gray-50 dark:bg-gray-900 rounded-[32px] p-6">
        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-4 flex items-center gap-2">
          <Star size={16} className="text-amber-500" /> Recent Achievements
        </h3>
        {stats.badges.length > 0 ? (
          <div className="flex flex-wrap gap-3">
            {stats.badges.map((badge, i) => (
              <motion.div 
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="bg-white dark:bg-black p-3 rounded-2xl shadow-sm border border-indigo-100 dark:border-indigo-900/30 flex items-center gap-2"
              >
                <div className="w-6 h-6 bg-indigo-100 rounded-lg flex items-center justify-center text-indigo-600">
                  <Star size={12} className="fill-indigo-600" />
                </div>
                <span className="text-xs font-bold whitespace-nowrap">{badge}</span>
              </motion.div>
            ))}
          </div>
        ) : (
          <p className="text-gray-400 text-sm italic">Start learning to earn badges!</p>
        )}
      </div>

      {/* Progress Chart Placeholder */}
      <div className="bg-white dark:bg-gray-900 p-6 rounded-[32px] border border-gray-100 dark:border-gray-800">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold">Weekly Activity</h3>
          <TrendingUp size={20} className="text-green-500" />
        </div>
        <div className="flex items-end justify-between h-24 gap-2">
          {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-2">
              <motion.div 
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                className={`w-full rounded-t-lg ${i === 3 ? 'bg-indigo-600' : 'bg-indigo-100 dark:bg-indigo-900/30'}`}
              />
              <span className="text-[10px] font-bold text-gray-400">{['M', 'T', 'W', 'T', 'F', 'S', 'S'][i]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode, label: string, value: string, sub: string }) {
  return (
    <motion.div 
      whileHover={{ y: -4 }}
      className="bg-white dark:bg-gray-900 p-5 rounded-[28px] border border-gray-100 dark:border-gray-800 shadow-sm"
    >
      <div className="bg-gray-50 dark:bg-black p-2 w-fit rounded-xl mb-3">
        {icon}
      </div>
      <p className="text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-1">{label}</p>
      <p className="text-xl font-black mb-1">{value}</p>
      <p className="text-[10px] text-gray-400">{sub}</p>
    </motion.div>
  );
}
