import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { aiService } from '../services/aiService';
import { Word, QuizQuestion } from '../types';
import { ArrowRight, CheckCircle, XCircle, Brain, RefreshCcw } from 'lucide-react';

export function Quiz({ glossary, onComplete }: { glossary: Word[], onComplete: (xp: number) => void }) {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);

  const loadQuiz = async () => {
    setLoading(true);
    const randomWords = [...glossary].sort(() => Math.random() - 0.5).slice(0, 5);
    const q = await aiService.generateQuiz(randomWords);
    setQuestions(q);
    setLoading(false);
  };

  useEffect(() => {
    loadQuiz();
  }, [glossary]);

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
  };

  const handleCheck = () => {
    if (selectedOption === null) return;
    setIsAnswered(true);
    if (selectedOption === questions[currentIndex].correctIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(c => c + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      onComplete(score * 50); // Give XP
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 space-y-4">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full"
        />
        <p className="text-gray-500 font-bold animate-pulse text-sm">Generating Quiz with AI...</p>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="p-10 text-center space-y-4">
        <Brain size={48} className="mx-auto text-gray-300" />
        <p className="text-gray-500">Failed to generate quiz. Try again?</p>
        <button onClick={loadQuiz} className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold">Retry</button>
      </div>
    );
  }

  const currentQ = questions[currentIndex];

  return (
    <div className="px-6 py-8 space-y-8">
      <div className="flex justify-between items-center text-xs font-bold text-gray-400">
        <span>QUESTION {currentIndex + 1} OF {questions.length}</span>
        <span className="text-indigo-600">SCORE: {score}</span>
      </div>

      <div className="w-full h-1.5 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
        <motion.div 
          animate={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          className="h-full bg-indigo-600"
        />
      </div>

      <motion.div
        key={currentIndex}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="space-y-6"
      >
        <h2 className="text-2xl font-black leading-tight text-gray-900 dark:text-white">
          {currentQ.question}
        </h2>

        <div className="space-y-3">
          {currentQ.options.map((option, i) => (
            <motion.button
              key={i}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleSelect(i)}
              className={`w-full p-5 rounded-2xl text-left font-bold transition-all border-2 flex items-center justify-between ${
                isAnswered 
                  ? i === currentQ.correctIndex 
                    ? "bg-green-100 border-green-500 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                    : i === selectedOption
                      ? "bg-red-100 border-red-500 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                      : "bg-gray-50 border-transparent text-gray-400 dark:bg-gray-900"
                  : selectedOption === i
                    ? "bg-indigo-100 border-indigo-600 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400"
                    : "bg-gray-50 border-transparent hover:border-gray-200 dark:bg-gray-900 dark:hover:border-gray-800"
              }`}
            >
              <span>{option}</span>
              {isAnswered && i === currentQ.correctIndex && <CheckCircle size={20} />}
              {isAnswered && i === selectedOption && i !== currentQ.correctIndex && <XCircle size={20} />}
            </motion.button>
          ))}
        </div>

        <AnimatePresence>
          {isAnswered && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-5 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl border border-indigo-100 dark:border-indigo-900/30"
            >
              <p className="text-sm font-medium text-indigo-800 dark:text-indigo-300">
                <span className="font-bold">Summary:</span> {currentQ.explanation}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      <div className="pt-4">
        {!isAnswered ? (
          <button 
            disabled={selectedOption === null}
            onClick={handleCheck}
            className="w-full bg-indigo-600 disabled:opacity-50 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-600/20 active:scale-95 transition-all"
          >
            Check Answer
          </button>
        ) : (
          <button 
            onClick={handleNext}
            className="w-full bg-gray-900 dark:bg-white text-white dark:text-black py-4 rounded-2xl font-bold flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            {currentIndex === questions.length - 1 ? 'Finish Quiz' : 'Next Question'} <ArrowRight size={20} />
          </button>
        )}
      </div>
    </div>
  );
}
