/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Heart, 
  BookOpen, 
  Volume2, 
  RotateCcw, 
  Info, 
  Home as HomeIcon, 
  ChevronLeft,
  X,
  Zap,
  TrendingUp,
  History,
  Star,
  Award,
  Sparkles,
  Brain,
  MessageSquare,
  LayoutDashboard,
  Mic,
  ArrowRight,
  RefreshCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GLOSSARY } from './data/glossary';
import { Word, Subject, SearchHistoryItem } from './types';
import { useUserStats } from './hooks/useUserStats';
import { Dashboard } from './components/Dashboard';
import { Quiz } from './components/Quiz';
import { AIChat } from './components/AIChat';
import { aiService } from './services/aiService';

// --- Components ---

const TTSButton = ({ text, className = "" }: { text: string, className?: string }) => {
  const speak = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <button 
      onClick={(e) => { e.stopPropagation(); speak(); }}
      className={`p-2 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 hover:scale-110 transition-transform ${className}`}
      aria-label="Speak"
    >
      <Volume2 size={20} />
    </button>
  );
};

const SubjectBadge = ({ subject }: { subject: Subject }) => {
  const colors = {
    Science: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
    Mathematics: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    Commerce: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
    General: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400"
  };

  return (
    <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full ${colors[subject]}`}>
      {subject}
    </span>
  );
};

// --- App Shell ---

type Screen = 'home' | 'detail' | 'saved' | 'flashcards' | 'about' | 'dashboard' | 'quiz';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [selectedWord, setSelectedWord] = useState<Word | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<Subject | "All">("All");
  const [savedWords, setSavedWords] = useState<number[]>([]);
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<number[]>([]);
  const [darkMode, setDarkMode] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const { stats, addXP, updateStreak, incrementWordsLearned } = useUserStats();

  // Initialize
  useEffect(() => {
    updateStreak();
    const saved = localStorage.getItem('nalla_nudi_saved');
    if (saved) setSavedWords(JSON.parse(saved));
    
    const hist = localStorage.getItem('nalla_nudi_history');
    if (hist) setHistory(JSON.parse(hist));

    const recent = localStorage.getItem('nalla_nudi_recent');
    if (recent) setRecentlyViewed(JSON.parse(recent));

    if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('nalla_nudi_saved', JSON.stringify(savedWords));
  }, [savedWords]);

  useEffect(() => {
    localStorage.setItem('nalla_nudi_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('nalla_nudi_recent', JSON.stringify(recentlyViewed));
  }, [recentlyViewed]);

  useEffect(() => {
    if (searchQuery.length > 2) {
      const available = GLOSSARY.map(w => w.englishWord);
      aiService.smartSearchSuggestion(searchQuery, available).then(setSuggestions);
    } else {
      setSuggestions([]);
    }
  }, [searchQuery]);

  const toggleSave = (id: number) => {
    setSavedWords(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const addToHistory = (word: string) => {
    if (!word.trim()) return;
    const newItem = { id: Date.now(), word, timestamp: Date.now() };
    setHistory(prev => [newItem, ...prev.filter(i => i.word !== word)].slice(0, 5));
  };

  const addToRecent = (id: number) => {
    setRecentlyViewed(prev => [id, ...prev.filter(i => i !== id)].slice(0, 5));
  };

  const filteredWords = useMemo(() => {
    return GLOSSARY.filter(w => {
      const matchesSearch = w.englishWord.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           w.kannadaMeaning.includes(searchQuery);
      const matchesFilter = activeFilter === "All" || w.subject === activeFilter;
      return matchesSearch && matchesFilter;
    });
  }, [searchQuery, activeFilter]);

  const wordOfTheDay = useMemo(() => {
    const today = new Date().toDateString();
    let seed = 0;
    for (let i = 0; i < today.length; i++) seed += today.charCodeAt(i);
    return GLOSSARY[seed % GLOSSARY.length];
  }, []);

  const navigateToDetail = (word: Word) => {
    setSelectedWord(word);
    if (!recentlyViewed.includes(word.id)) {
      addToRecent(word.id);
      addXP(10);
      incrementWordsLearned();
    }
    setCurrentScreen('detail');
  };

  const renderHome = () => (
    <div className="space-y-6 pb-24">
      {/* Premium Top Bar */}
      <div className="pt-8 px-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <BookOpen size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">Nalla-Nudi</h1>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <p className="text-gray-400 text-[10px] uppercase font-bold tracking-widest">Level {stats.level} Student</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <motion.div 
            whileTap={{ scale: 0.9 }}
            onClick={() => setCurrentScreen('dashboard')}
            className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl cursor-pointer"
          >
            <Zap size={16} className="text-orange-500 fill-orange-500" />
            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">{stats.streak}</span>
          </motion.div>
          <button 
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 transition-colors"
          >
            {darkMode ? <Star size={20} className="fill-yellow-400 text-yellow-400" /> : <Star size={20} />}
          </button>
        </div>
      </div>

      {/* Hero Search Area */}
      <div className="px-6 space-y-4">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-600 transition-colors" size={20} />
          <input 
            type="text" 
            placeholder="Search words, concepts..."
            className="w-full bg-gray-100 dark:bg-gray-900 border-none rounded-[28px] py-5 pl-14 pr-12 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none text-gray-800 dark:text-white font-medium"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addToHistory(searchQuery)}
          />
          <button className="absolute right-4 top-1/2 -translate-y-1/2 text-indigo-400 hover:text-indigo-600 transition-colors">
            <Mic size={20} />
          </button>
        </div>

        {/* AI Suggestions */}
        <AnimatePresence>
          {suggestions.length > 0 && searchQuery && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-wrap gap-2 px-1"
            >
              {suggestions.map((s, i) => (
                <button 
                  key={i}
                  onClick={() => setSearchQuery(s)}
                  className="px-3 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg text-[10px] font-bold border border-indigo-100 dark:border-indigo-900/30 flex items-center gap-1"
                >
                  <Sparkles size={10} /> {s}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto py-2 no-scrollbar">
          {["All", "Science", "Mathematics", "Commerce"].map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f as any)}
              className={`px-5 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
                activeFilter === f 
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 scale-105" 
                : "bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-gray-700 border border-transparent hover:border-gray-200 dark:hover:border-gray-700"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {searchQuery ? (
        /* Search Results with Glassmorphism Effect */
        <div className="px-6 space-y-4">
          <div className="flex justify-between items-center px-1">
            <h2 className="text-sm font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <TrendingUp size={16} /> Results ({filteredWords.length})
            </h2>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {filteredWords.map(word => (
              <WordCompactCard 
                key={word.id} 
                word={word} 
                onClick={() => navigateToDetail(word)} 
                isSaved={savedWords.includes(word.id)} 
                onToggleSave={() => toggleSave(word.id)} 
              />
            ))}
          </div>
          {filteredWords.length === 0 && (
            <div className="text-center py-20 grayscale opacity-50">
              <Search size={64} className="mx-auto mb-4 text-gray-300" />
              <p className="font-bold text-gray-400">No matches found</p>
              <p className="text-xs text-gray-400 mt-1">Try searching for a related topic</p>
            </div>
          )}
        </div>
      ) : (
        /* Dynamic Feed */
        <div className="px-6 space-y-10">
          {/* XP Progress Small */}
          <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-3xl border border-indigo-100 dark:border-indigo-900/30">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 tracking-wider">DAILY XP GOAL</span>
              <span className="text-[10px] font-black">{stats.xp % 100} / 100</span>
            </div>
            <div className="h-1.5 bg-indigo-200 dark:bg-indigo-900/50 rounded-full overflow-hidden">
               <motion.div 
                 initial={{ width: 0 }}
                 animate={{ width: `${stats.xp % 100}%` }}
                 className="h-full bg-indigo-600"
               />
            </div>
          </div>

          {/* Word of the Day - Premium Design */}
          <section>
            <div className="flex justify-between items-center px-1 mb-4">
              <h2 className="text-sm font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                <Star size={16} className="text-amber-500 fill-amber-500" /> Today's Focus
              </h2>
            </div>
            <motion.div 
              whileTap={{ scale: 0.98 }}
              onClick={() => navigateToDetail(wordOfTheDay)}
              className="bg-white dark:bg-gray-900 rounded-[40px] p-8 shadow-2xl shadow-indigo-500/10 relative overflow-hidden group cursor-pointer border border-gray-100 dark:border-gray-800"
            >
              <div className="relative z-10 space-y-6">
                <div className="flex justify-between items-center">
                  <SubjectBadge subject={wordOfTheDay.subject} />
                  <div className="flex items-center gap-1 text-xs font-bold text-indigo-500">
                    +50 XP <Zap size={14} className="fill-indigo-500" />
                  </div>
                </div>
                <div>
                  <h3 className="text-5xl font-black mb-2 tracking-tighter text-gray-900 dark:text-white leading-none">
                    {wordOfTheDay.englishWord}
                  </h3>
                  <div className="flex items-center gap-3">
                    <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400">{wordOfTheDay.kannadaMeaning}</p>
                    <TTSButton text={wordOfTheDay.englishWord} />
                  </div>
                </div>
                <div className="pt-2 flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-widest">
                  Master this word <ArrowRight size={14} />
                </div>
              </div>
              <div className="absolute -right-12 -bottom-12 opacity-[0.03] dark:opacity-[0.05] group-hover:scale-110 transition-transform duration-700">
                <Sparkles size={240} />
              </div>
            </motion.div>
          </section>

          {/* Feature Grid */}
          <div className="grid grid-cols-2 gap-4">
            <FeatureCard 
              icon={<RotateCcw />} 
              title="Flashcards" 
              desc="Daily practice" 
              color="bg-orange-500"
              onClick={() => setCurrentScreen('flashcards')}
            />
            <FeatureCard 
              icon={<Brain />} 
              title="AI Quiz" 
              desc="Win XP badges" 
              color="bg-purple-600"
              onClick={() => setCurrentScreen('quiz')}
            />
          </div>

          {/* Recently Viewed */}
          {recentlyViewed.length > 0 && (
            <section>
              <h2 className="text-sm font-black text-gray-400 uppercase tracking-widest px-1 mb-4 flex items-center gap-2">
                <History size={16} /> Recent Activity
              </h2>
              <div className="space-y-4">
                {recentlyViewed.map(id => {
                  const word = GLOSSARY.find(w => w.id === id);
                  if (!word) return null;
                  return (
                    <WordCompactCard key={word.id} word={word} onClick={() => navigateToDetail(word)} isSaved={savedWords.includes(word.id)} onToggleSave={() => toggleSave(word.id)} />
                  );
                })}
              </div>
            </section>
          )}

          {/* AI Bot Banner */}
          <section 
            onClick={() => setShowChat(true)}
            className="bg-indigo-600 rounded-[32px] p-6 text-white flex items-center justify-between shadow-xl shadow-indigo-500/20 cursor-pointer overflow-hidden relative"
          >
            <div className="relative z-10">
              <h3 className="font-black text-xl mb-1">Need help?</h3>
              <p className="text-indigo-100 text-xs font-bold opacity-80">Ask your Nalla-Nudi assistant</p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md relative z-10">
              <MessageSquare size={24} />
            </div>
            <div className="absolute -left-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-2xl" />
          </section>
        </div>
      )}
    </div>
  );

  return (
    <div className={`${darkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white font-sans max-w-md mx-auto relative shadow-2xl">
        <AnimatePresence mode="wait">
          {currentScreen === 'home' && (
            <motion.div 
              key="home"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              {renderHome()}
            </motion.div>
          )}

          {currentScreen === 'detail' && selectedWord && (
            <ScreenWrapper title="Detail" onBack={() => setCurrentScreen('home')}>
              <div className="px-6 space-y-8 py-4">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <SubjectBadge subject={selectedWord.subject} />
                    <button 
                      onClick={() => toggleSave(selectedWord.id)}
                      className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-900 text-gray-400"
                    >
                      <Heart size={24} className={savedWords.includes(selectedWord.id) ? "fill-red-500 text-red-500" : ""} />
                    </button>
                  </div>
                  <h2 className="text-5xl font-extrabold tracking-tight mb-2">{selectedWord.englishWord}</h2>
                  <div className="flex items-center gap-3">
                    <p className="text-2xl text-blue-600 dark:text-blue-400 font-bold">{selectedWord.kannadaMeaning}</p>
                    <TTSButton text={selectedWord.englishWord} />
                  </div>
                </div>

                <div className="space-y-6">
                  <section className="bg-gray-50 dark:bg-gray-900 p-6 rounded-[32px]">
                    <h3 className="text-xs uppercase tracking-widest font-bold text-gray-400 mb-3 flex items-center gap-2">
                      <Info size={14} /> Explanation
                    </h3>
                    <p className="text-lg leading-relaxed text-gray-700 dark:text-gray-300 font-medium">
                      {selectedWord.explanation}
                    </p>
                  </section>

                  <section className="p-6 border-l-4 border-blue-500 bg-blue-50/50 dark:bg-blue-900/10 rounded-r-3xl">
                    <h3 className="text-xs uppercase tracking-widest font-bold text-blue-500 mb-3">Example Sentence</h3>
                    <p className="text-lg italic text-gray-800 dark:text-white">
                      "{selectedWord.exampleSentence}"
                    </p>
                  </section>
                </div>

                <button 
                  onClick={() => setCurrentScreen('flashcards')}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 transition-all active:scale-95"
                >
                  <RotateCcw size={20} /> Practice with Flashcards
                </button>
              </div>
            </ScreenWrapper>
          )}

          {currentScreen === 'saved' && (
            <ScreenWrapper title="My List" onBack={() => setCurrentScreen('home')}>
              <div className="px-4 space-y-4 py-4">
                {savedWords.length === 0 ? (
                  <div className="text-center py-20 text-gray-500">
                    <Heart size={48} className="mx-auto mb-4 opacity-20" />
                    <p>Your saved words will appear here.</p>
                  </div>
                ) : (
                  savedWords.map(id => {
                    const word = GLOSSARY.find(w => w.id === id);
                    if (!word) return null;
                    return <WordCompactCard key={word.id} word={word} onClick={() => navigateToDetail(word)} isSaved={true} onToggleSave={() => toggleSave(word.id)} />;
                  })
                )}
              </div>
            </ScreenWrapper>
          )}

          {currentScreen === 'flashcards' && (
            <ScreenWrapper title="Revision" onBack={() => setCurrentScreen('home')}>
              <FlashcardScreen savedIds={savedWords} onDetail={navigateToDetail} />
            </ScreenWrapper>
          )}

          {currentScreen === 'about' && (
            <ScreenWrapper title="About" onBack={() => setCurrentScreen('home')}>
              <div className="px-6 py-8 space-y-8">
                <div className="text-center space-y-4">
                  <div className="w-24 h-24 bg-blue-600 rounded-[32px] mx-auto flex items-center justify-center text-white shadow-xl shadow-blue-500/20">
                    <BookOpen size={48} />
                  </div>
                  <div>
                    <h2 className="text-3xl font-extrabold tracking-tight">Nalla-Nudi</h2>
                    <p className="text-blue-500 font-bold uppercase tracking-widest text-[10px]">Version 1.0.0</p>
                  </div>
                </div>

                <div className="space-y-6 text-gray-600 dark:text-gray-400 leading-relaxed">
                  <p>
                    <strong>Nalla-Nudi</strong> is an educational initiative designed to bridge the gap between regional language education
                    and technical global standards.
                  </p>
                  <p>
                    Specifically tailored for Kannada-medium students, this app provides clear, culturally contextual explanations
                    of complex terms in Science, Mathematics, and Commerce.
                  </p>
                  
                  <div className="bg-gray-100 dark:bg-gray-900 rounded-3xl p-6 space-y-4 border border-gray-200 dark:border-gray-800">
                    <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-2"><Zap size={18} className="text-blue-500" /> Features</h3>
                    <ul className="grid grid-cols-1 gap-2 text-sm">
                      <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-blue-500" /> 100% Offline Database</li>
                      <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-blue-500" /> Simple Kannada Context</li>
                      <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-blue-500" /> English Audio Pronunciation</li>
                      <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-blue-500" /> Flashcard Revision System</li>
                    </ul>
                  </div>
                </div>
              </div>
            </ScreenWrapper>
          )}
        </AnimatePresence>

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/90 dark:bg-black/90 backdrop-blur-xl border-t border-gray-100 dark:border-gray-800 px-6 py-4 flex justify-between items-center z-50">
          <NavButton active={currentScreen === 'home'} onClick={() => { setCurrentScreen('home'); setSearchQuery(""); }} icon={<HomeIcon />} label="Home" />
          <NavButton active={currentScreen === 'saved'} onClick={() => setCurrentScreen('saved')} icon={<Heart />} label="Saved" />
          <NavButton active={currentScreen === 'flashcards'} onClick={() => setCurrentScreen('flashcards')} icon={<RotateCcw />} label="Revise" />
          <NavButton active={currentScreen === 'about'} onClick={() => setCurrentScreen('about')} icon={<Info />} label="About" />
        </nav>
      </div>
    </div>
  );
}

const NavButton = ({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-all ${active ? "text-indigo-600 dark:text-indigo-400 scale-110" : "text-gray-400 dark:text-gray-600"}`}
  >
    <div className={`p-2 rounded-xl ${active ? "bg-indigo-100 dark:bg-indigo-900/30" : ""}`}>
      {React.cloneElement(icon as React.ReactElement, { size: 24, className: active ? "fill-indigo-600 dark:fill-indigo-400" : "" })}
    </div>
    <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
  </button>
);

const ScreenWrapper = ({ title, children, onBack }: { title: string, children: React.ReactNode, onBack: () => void }) => (
  <motion.div 
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -20 }}
    className="min-h-screen pb-24"
  >
    <header className="px-6 py-6 flex items-center justify-between sticky top-0 bg-white/80 dark:bg-black/80 backdrop-blur-md z-10 border-b border-gray-100 dark:border-gray-800/50">
      <button onClick={onBack} className="p-3 rounded-2xl bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 transition-colors">
        <ChevronLeft size={24} />
      </button>
      <h2 className="text-xl font-black tracking-tight uppercase text-sm">{title}</h2>
      <div className="w-12 text-indigo-100 flex justify-end"><Sparkles size={20} /></div>
    </header>
    {children}
  </motion.div>
);

const FeatureCard = ({ icon, title, desc, color, onClick }: { icon: React.ReactNode, title: string, desc: string, color: string, onClick: () => void }) => (
  <motion.div 
    whileHover={{ y: -4 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className="bg-white dark:bg-gray-900 p-6 rounded-[32px] shadow-lg shadow-gray-200/30 dark:shadow-none border border-gray-100 dark:border-gray-800 cursor-pointer flex flex-col gap-4"
  >
    <div className={`w-12 h-12 ${color} rounded-2xl flex items-center justify-center text-white shadow-lg shadow-current/20`}>
      {React.cloneElement(icon as React.ReactElement, { size: 24 })}
    </div>
    <div>
      <h3 className="font-black text-gray-900 dark:text-white leading-tight">{title}</h3>
      <p className="text-[10px] font-bold text-gray-400 mt-0.5 tracking-wider uppercase">{desc}</p>
    </div>
  </motion.div>
);

const WordCompactCard = ({ word, onClick, isSaved, onToggleSave }: { word: Word, onClick: () => void, isSaved: boolean, onToggleSave: () => void, key?: any }) => (
  <motion.div 
    whileHover={{ x: 4 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className="bg-white dark:bg-gray-900 rounded-[32px] p-6 flex items-center justify-between group cursor-pointer border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-xl hover:shadow-indigo-500/5 transition-all"
  >
    <div className="flex-1">
      <div className="flex items-center gap-2 mb-2">
        <SubjectBadge subject={word.subject} />
      </div>
      <h3 className="text-2xl font-black text-gray-900 dark:text-white capitalize tracking-tight">{word.englishWord}</h3>
      <p className="text-indigo-500 font-bold text-sm tracking-wide">{word.kannadaMeaning}</p>
    </div>
    <div className="flex items-center gap-2">
      <button 
        onClick={(e) => { e.stopPropagation(); onToggleSave(); }}
        className="p-3 rounded-2xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
      >
        <Heart size={24} className={isSaved ? "fill-red-500 text-red-500" : "text-gray-300"} />
      </button>
       <div className="w-12 h-12 bg-gray-50 dark:bg-gray-800 rounded-full flex items-center justify-center text-gray-300 group-hover:text-indigo-600 transition-colors">
        <ChevronLeft size={24} className="rotate-180" />
      </div>
    </div>
  </motion.div>
);

// --- Flashcard Screen ---

const FlashcardScreen = ({ savedIds, onDetail }: { savedIds: number[], onDetail: (w: Word) => void }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const playlist = useMemo(() => {
    const list = savedIds.length > 0 
      ? GLOSSARY.filter(w => savedIds.includes(w.id))
      : GLOSSARY.sort(() => Math.random() - 0.5).slice(0, 10);
    return list;
  }, [savedIds]);

  const currentWord = playlist[currentIndex];

  if (!currentWord) return null;

  return (
    <div className="px-6 py-4 space-y-8 flex flex-col items-center">
      <div className="w-full flex justify-between items-center text-sm font-bold text-gray-400">
        <span>PROGRESS</span>
        <span>{currentIndex + 1} / {playlist.length}</span>
      </div>
      
      <div className="w-full h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${((currentIndex + 1) / playlist.length) * 100}%` }}
          className="h-full bg-blue-600"
        />
      </div>

      <div className="w-full aspect-[4/5] relative perspective-1000">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentWord.id + (isFlipped ? "-back" : "-front")}
            initial={{ opacity: 0, rotateY: isFlipped ? 90 : -90, scale: 0.8 }}
            animate={{ opacity: 1, rotateY: 0, scale: 1 }}
            exit={{ opacity: 0, rotateY: isFlipped ? -90 : 90, scale: 0.8 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            onClick={() => setIsFlipped(!isFlipped)}
            className={`w-full h-full rounded-[40px] shadow-2xl flex flex-col items-center justify-center p-8 text-center cursor-pointer select-none ${
              isFlipped 
                ? "bg-white dark:bg-gray-900 border-4 border-indigo-500" 
                : "bg-blue-600 text-white"
            }`}
          >
            {!isFlipped ? (
              <>
                <BookOpen size={48} className="mb-6 opacity-30" />
                <h3 className="text-xs uppercase tracking-[0.2em] font-black opacity-60 mb-2">Technical Term</h3>
                <h2 className="text-5xl font-black tracking-tight leading-tight">{currentWord.englishWord}</h2>
                <p className="mt-8 text-sm font-bold uppercase tracking-widest opacity-60">Tap to flip</p>
              </>
            ) : (
              <div className="space-y-6">
                <SubjectBadge subject={currentWord.subject} />
                <h2 className="text-3xl font-black text-indigo-600 dark:text-indigo-400">{currentWord.kannadaMeaning}</h2>
                <div className="h-0.5 w-12 bg-gray-200 dark:bg-gray-800 mx-auto" />
                <p className="text-lg font-medium leading-relaxed">{currentWord.explanation}</p>
                <div className="pt-4">
                   <TTSButton text={currentWord.englishWord} />
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="w-full flex gap-4 pt-4">
        <button 
          disabled={currentIndex === 0}
          onClick={() => { setIsFlipped(false); setCurrentIndex(c => c - 1); }}
          className="flex-1 py-4 rounded-2xl bg-gray-100 dark:bg-gray-800 font-bold text-gray-500 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <ChevronLeft /> PREV
        </button>
        {currentIndex === playlist.length - 1 ? (
           <button 
           onClick={() => onDetail(currentWord)}
           className="flex-[2] py-4 rounded-2xl bg-green-600 text-white font-bold shadow-lg shadow-green-500/20"
         >
           FINISH & REVIEW
         </button>
        ) : (
          <button 
            onClick={() => { setIsFlipped(false); setCurrentIndex(c => c + 1); }}
            className="flex-[2] py-4 rounded-2xl bg-blue-600 text-white font-bold shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 group"
          >
            NEXT <ChevronLeft className="rotate-180 group-hover:translate-x-1 transition-transform" />
          </button>
        )}
      </div>
    </div>
  );
};
