import { Word } from "../types";

export const GLOSSARY: Word[] = [
  // Science
  {
    id: 1,
    englishWord: "Gravity",
    kannadaMeaning: "ಗುರುತ್ವಾಕರ್ಷಣೆ",
    explanation: "ಭೂಮಿಯು ವಸ್ತುಗಳನ್ನು ತನ್ನ ಕಡೆಗೆ ಎಳೆಯುವ ಶಕ್ತಿ.",
    subject: "Science",
    exampleSentence: "Gravity pulls objects toward Earth."
  },
  {
    id: 2,
    englishWord: "Evaporation",
    kannadaMeaning: "ಆವಿಯಾಗುವಿಕೆ",
    explanation: "ನೀರು ಬಿಸಿಯಾಗಿ ಅನಿಲವಾಗಿ ಬದಲಾಗುವುದು.",
    subject: "Science",
    exampleSentence: "The sun causes the evaporation of water."
  },
  {
    id: 3,
    englishWord: "Photosynthesis",
    kannadaMeaning: "ದ್ಯುತಿಸಂಶ್ಲೇಷಣೆ",
    explanation: "ಸಸ್ಯಗಳು ಸೂರ್ಯನ ಬೆಳಕನ್ನು ಬಳಸಿ ಆಹಾರ ತಯಾರಿಸುವ ಪ್ರಕ್ರಿಯೆ.",
    subject: "Science",
    exampleSentence: "Plants need sunlight for photosynthesis."
  },
  {
    id: 4,
    englishWord: "Evolution",
    kannadaMeaning: "ವಿಕಾಸ / ಜೀವನದ ಬೆಳವಣಿಗೆ",
    explanation: "ಜೀವಿಗಳು ಕಾಲಕ್ರಮೇಣ ಬದಲಾವಣೆ ಹೊಂದುವ ಪ್ರಕ್ರಿಯೆ.",
    subject: "Science",
    exampleSentence: "Darwin explained the theory of evolution."
  },
  {
    id: 5,
    englishWord: "Atmosphere",
    kannadaMeaning: "ವಾತಾವರಣ",
    explanation: "ಭೂಮಿಯ ಸುತ್ತಲಿರುವ ಗಾಳಿಯ ಪದರ.",
    subject: "Science",
    exampleSentence: "The atmosphere protects us from space radiation."
  },
  {
    id: 6,
    englishWord: "Density",
    kannadaMeaning: "ಸಾಂದ್ರತೆ",
    explanation: "ಒಂದು ವಸ್ತುವಿನ ದ್ರವ್ಯರಾಶಿ ಮತ್ತು ಅದರ ಘನ ಗಾತ್ರದ ನಡುವಿನ ಸಂಬಂಧ.",
    subject: "Science",
    exampleSentence: "Oil has a lower density than water."
  },
  {
    id: 7,
    englishWord: "Friction",
    kannadaMeaning: "ಘರ್ಷಣೆ",
    explanation: "ಎರಡು ವಸ್ತುಗಳ ನಡುವೆ ಚಲನವಲನದ ವಿರುದ್ಧ ಕಾಡುವ ಶಕ್ತಿ.",
    subject: "Science",
    exampleSentence: "Rough surfaces create more friction."
  },
  {
    id: 8,
    englishWord: "Magnetism",
    kannadaMeaning: "ಕಾಂತೀಯತೆ",
    explanation: "ಕಾಂತವು ಕಬ್ಬಿಣದ ವಸ್ತುಗಳನ್ನು ಎಳೆಯುವ ಶಕ್ತಿ.",
    subject: "Science",
    exampleSentence: "Magnetism pull metallic paperclips."
  },
  {
    id: 9,
    englishWord: "Velocity",
    kannadaMeaning: "ವೇಗ / ಜವ",
    explanation: "ಒಂದು ನಿರ್ದಿಷ್ಟ ದಿಕ್ಕಿನಲ್ಲಿ ವಸ್ತುವಿನ ಚಲನೆಯ ವೇಗ.",
    subject: "Science",
    exampleSentence: "The rocket attained high velocity."
  },
  {
    id: 10,
    englishWord: "Pollution",
    kannadaMeaning: "ಮಾಲಿನ್ಯ",
    explanation: "ಪರಿಸರಕ್ಕೆ ಹಾನಿಕಾರಕ ವಸ್ತುಗಳ ಸೇರ್ಪಡೆ.",
    subject: "Science",
    exampleSentence: "Air pollution is harmful to health."
  },
  {
    id: 11,
    englishWord: "Respiration",
    kannadaMeaning: "ಉಸಿರಾಟ",
    explanation: "ಜೀವಿಗಳು ಆಮ್ಲಜನಕ ಪಡೆದು ಶಕ್ತಿ ಬಿಡುಗಡೆ ಮಾಡುವ ಪ್ರಕ್ರಿಯೆ.",
    subject: "Science",
    exampleSentence: "Respiration happens in all living cells."
  },
  {
    id: 12,
    englishWord: "Microscope",
    kannadaMeaning: "ಸೂಕ್ಷ್ಮದರ್ಶಕ",
    explanation: "ಕಣ್ಣಿಗೆ ಕಾಣದ ಸಣ್ಣ ವಸ್ತುಗಳನ್ನು ದೊಡ್ಡದಾಗಿ ನೋಡಲು ಬಳಸುವ ಉಪಕರಣ.",
    subject: "Science",
    exampleSentence: "We used a microscope to see bacteria."
  },
  {
    id: 13,
    englishWord: "Heredity",
    kannadaMeaning: "ಅನುವಂಶಿಕತೆ",
    explanation: "ಪೋಷಕರಿಂದ ಗುಣಲಕ್ಷಣಗಳು ಮುಂದಿನ ಪೀಳಿಗೆಗೆ ಹರಿಯುವಿಕೆ.",
    subject: "Science",
    exampleSentence: "Eye color is determined by heredity."
  },
  {
    id: 14,
    englishWord: "Ecosystem",
    kannadaMeaning: "ಪರಿಸರ ವ್ಯವಸ್ಥೆ",
    explanation: "ಜೀವಿಗಳು ಮತ್ತು ಅವುಗಳ ಸುತ್ತಲಿನ ನಿರ್ಜೀವ ಪರಿಸರದ ನಡುವಿನ ಸಂಬಂಧ.",
    subject: "Science",
    exampleSentence: "A pond is a small ecosystem."
  },
  {
    id: 15,
    englishWord: "Chemical Reaction",
    kannadaMeaning: "ರಾಸಾಯನಿಕ ಕ್ರಿಯೆ",
    explanation: "ಒಂದು ಅಥವಾ ಹೆಚ್ಚು ವಸ್ತುಗಳು ಬದಲಾಗಿ ಹೊಸ ವಸ್ತುಗಳು ಉಂಟಾಗುವ ಪ್ರಕ್ರಿಯೆ.",
    subject: "Science",
    exampleSentence: "Baking bread involves a chemical reaction."
  },
  {
    id: 16,
    englishWord: "Renewable",
    kannadaMeaning: "ಪುನರ್ಬಳಕೆ ಮಾಡಬಹುದಾದ",
    explanation: "ಮತ್ತೆ ಮತ್ತೆ ಪಡೆಯಬಹುದಾದ ಶಕ್ತಿಯ ಮೂಲಗಳು (ಸೂರ್ಯ, ಗಾಳಿ).",
    subject: "Science",
    exampleSentence: "Solar energy is a renewable resource."
  },

  // Mathematics
  {
    id: 17,
    englishWord: "Equation",
    kannadaMeaning: "ಸಮೀಕರಣ",
    explanation: "ಎರಡು ಗಣಿತದ ಅಭಿವ್ಯಕ್ತಿಗಳು ಸಮಾನವೆಂದು ತೋರಿಸುವುದು.",
    subject: "Mathematics",
    exampleSentence: "Solve the equation for x."
  },
  {
    id: 18,
    englishWord: "Fraction",
    kannadaMeaning: "ಭಿನ್ನರಾಶಿ",
    explanation: "ಒಂದು ಪೂರ್ಣ ವಸ್ತುವಿನ ಭಾಗಗಳನ್ನು ತೋರಿಸುವ ಸಂಖ್ಯೆ.",
    subject: "Mathematics",
    exampleSentence: "One-half is written as a fraction 1/2."
  },
  {
    id: 19,
    englishWord: "Diameter",
    kannadaMeaning: "ವ್ಯಾಸ",
    explanation: "ವೃತ್ತದ ಕೇಂದ್ರದ ಮೂಲಕ ಹಾದುಹೋಗುವ ಸರಳರೇಖೆ.",
    subject: "Mathematics",
    exampleSentence: "The diameter is twice the radius."
  },
  {
    id: 20,
    englishWord: "Percentage",
    kannadaMeaning: "ಶೇಕಡಾವಾರು",
    explanation: "ನೂರಕ್ಕೆ ಎಷ್ಟು ಎಂಬುದನ್ನು ಸೂಚಿಸುವ ಗಣಿತೀಯ ಪದ.",
    subject: "Mathematics",
    exampleSentence: "Eighty percent means 80 out of 100."
  },
  {
    id: 21,
    englishWord: "Circumference",
    kannadaMeaning: "ಪರಿಧಿ",
    explanation: "ವೃತ್ತದ ಸುತ್ತಳತೆ ಅಥವಾ ಅಳತೆ.",
    subject: "Mathematics",
    exampleSentence: "Use Pi to find the circumference."
  },
  {
    id: 22,
    englishWord: "Symmetry",
    kannadaMeaning: "ಸಮ್ಮಿತಿ",
    explanation: "ಒಂದು ವಸ್ತುವಿನ ಎರಡು ಬದಿಗಳು ಒಂದೇ ರೀತಿ ಇರುವುದು.",
    subject: "Mathematics",
    exampleSentence: "A butterfly has bilateral symmetry."
  },
  {
    id: 23,
    englishWord: "Variable",
    kannadaMeaning: "ಚರಾಕ್ಷರ",
    explanation: "ಬದಲಾಗಬಹುದಾದ ಬೆಲೆಯನ್ನು ಹೊಂದಿರುವ ಅಕ್ಷರ ಅಥವಾ ಚಿಹ್ನೆ.",
    subject: "Mathematics",
    exampleSentence: "In x + 5 = 10, x is the variable."
  },
  {
    id: 24,
    englishWord: "Probability",
    kannadaMeaning: "ಸಂಭವನೀಯತೆ",
    explanation: "ಒಂದು ಘಟನೆ ಘಟಿಸುವ ಸಾಧ್ಯತೆಯನ್ನು ಲೆಕ್ಕ ಹಾಕುವುದು.",
    subject: "Mathematics",
    exampleSentence: "What is the probability of tossing heads?"
  },
  {
    id: 25,
    englishWord: "Acute Angle",
    kannadaMeaning: "ಲಘು ಕೋನ",
    explanation: "೯೦ ಡಿಗ್ರಿಗಿಂತ ಕಡಿಮೆ ಇರುವ ಕೋನ.",
    subject: "Mathematics",
    exampleSentence: "A 45-degree angle is an acute angle."
  },
  {
    id: 26,
    englishWord: "Denominator",
    kannadaMeaning: "ಛೇದ",
    explanation: "ಭಿನ್ನರಾಶಿಯ ಕೆಳಗೆ ಬರೆಯುವ ಸಂಖ್ಯೆ.",
    subject: "Mathematics",
    exampleSentence: "In 3/4, 4 is the denominator."
  },
  {
    id: 27,
    englishWord: "Numerator",
    kannadaMeaning: "ಅಂಶ",
    explanation: "ಭಿನ್ನರಾಶಿಯ ಮೇಲೆ ಬರೆಯುವ ಸಂಖ್ಯೆ.",
    subject: "Mathematics",
    exampleSentence: "In 3/4, 3 is the numerator."
  },
  {
    id: 28,
    englishWord: "Polygon",
    kannadaMeaning: "ಬಹುಭುಜಾಕೃತಿ",
    explanation: "ಅನೇಕ ಬಾಹುಗಳು ಅಥವಾ ಭುಜಗಳನ್ನು ಹೊಂದಿರುವ ಆಕೃತಿ.",
    subject: "Mathematics",
    exampleSentence: "A hexagon is a six-sided polygon."
  },
  {
    id: 29,
    englishWord: "Hypotenuse",
    kannadaMeaning: "ವಿಕರ್ಣ",
    explanation: "ಲಂಬಕೋನ ತ್ರಿಕೋನದ ಅತಿ ಉದ್ದವಾದ ಬಾಹು.",
    subject: "Mathematics",
    exampleSentence: "The square of the hypotenuse is sum of squares of others."
  },
  {
    id: 30,
    englishWord: "Ratio",
    kannadaMeaning: "ಅನುಪಾತ",
    explanation: "ಎರಡು ಸಂಖ್ಯೆಗಳ ನಡುವಿನ ಸಂಬಂಧ ಅಥವಾ ಹೋಲಿಕೆ.",
    subject: "Mathematics",
    exampleSentence: "The ratio of boys to girls is 1:2."
  },
  {
    id: 31,
    englishWord: "Median",
    kannadaMeaning: "ಮಧ್ಯಂಕ",
    explanation: "ದತ್ತಾಂಶಗಳ ಸಮೂಹದಲ್ಲಿ ಮಧ್ಯದಲ್ಲಿರುವ ಬೆಲೆ.",
    subject: "Mathematics",
    exampleSentence: "Arrange numbers to find the median."
  },

  // Commerce
  {
    id: 32,
    englishWord: "Inflation",
    kannadaMeaning: "ಹಣದುಬ್ಬರ",
    explanation: "ವಸ್ತುಗಳ ಬೆಲೆಗಳು ಏರುವುದು ಮತ್ತು ಹಣದ ಮೌಲ್ಯ ಕಡಿಮೆಯಾಗುವುದು.",
    subject: "Commerce",
    exampleSentence: "Inflation reduces people's buying power."
  },
  {
    id: 33,
    englishWord: "Investment",
    kannadaMeaning: "ಹೂಡಿಕೆ",
    explanation: "ಲಾಭ ಗಳಿಸುವ ಉದ್ದೇಶದಿಂದ ವ್ಯವಹಾರದಲ್ಲಿ ತೊಡಗಿಸುವ ಹಣ.",
    subject: "Commerce",
    exampleSentence: "Stocks are a common type of investment."
  },
  {
    id: 34,
    englishWord: "Auditing",
    kannadaMeaning: "ಲೆಕ್ಕಪರಿಶೋಧನೆ",
    explanation: "ವ್ಯವಹಾರದ ಲೆಕ್ಕಪತ್ರಗಳನ್ನು ಅಧಿಕೃತವಾಗಿ ಪರಿಶೀಲಿಸುವುದು.",
    subject: "Commerce",
    exampleSentence: "Annual auditing is mandatory for large firms."
  },
  {
    id: 35,
    englishWord: "Liability",
    kannadaMeaning: "ಹೊಣೆಗಾರಿಕೆ / ಸಾಲ",
    explanation: "ಒಬ್ಬ ವ್ಯಕ್ತಿ ಅಥವಾ ಸಂಸ್ಥೆ ಇತರರಿಗೆ ಕೊಡಬೇಕಾದ ಹಣ.",
    subject: "Commerce",
    exampleSentence: "Bank loans are a company's liability."
  },
  {
    id: 36,
    englishWord: "Asset",
    kannadaMeaning: "ಆಸ್ತಿ / ಸಂಪತ್ತು",
    explanation: "ಸಂಸ್ಥೆ ಅಥವಾ ವ್ಯಕ್ತಿಯ ಒಡೆತನದಲ್ಲಿರುವ ಬೆಲೆಬಾಳುವ ವಸ್ತುಗಳು.",
    subject: "Commerce",
    exampleSentence: "Buildings and cash are business assets."
  },
  {
    id: 37,
    englishWord: "Capital",
    kannadaMeaning: "ಬಂಡವಾಳ",
    explanation: "ವ್ಯವಹಾರವನ್ನು ಆರಂಭಿಸಲು ಬಳಸುವ ಹಣ ಅಥವಾ ಸಂಪನ್ಮೂಲ.",
    subject: "Commerce",
    exampleSentence: "He started the shop with small capital."
  },
  {
    id: 38,
    englishWord: "Inventory",
    kannadaMeaning: "ದಾಸ್ತಾನು",
    explanation: "ಸಂಗ್ರಹಿಸಿಟ್ಟಿರುವ ಸರಕುಗಳ ಪಟ್ಟಿ ಅಥವಾ ಪ್ರಮಾಣ.",
    subject: "Commerce",
    exampleSentence: "Warehouse staff check the inventory daily."
  },
  {
    id: 39,
    englishWord: "Dividend",
    kannadaMeaning: "ಲಾಭಾಂಶ",
    explanation: "ಕಂಪನಿಯು ಗಳಿಸಿದ ಲಾಭದಲ್ಲಿ ಶೇರುದಾರರಿಗೆ ಹಂಚುವ ಭಾಗ.",
    subject: "Commerce",
    exampleSentence: "Shareholders receive yearly dividends."
  },
  {
    id: 40,
    englishWord: "Accounting",
    kannadaMeaning: "ಲೆಕ್ಕಶಾಸ್ತ್ರ",
    explanation: "ಹಣಕಾಸಿನ ವ್ಯವಹಾರಗಳನ್ನು ಕ್ರಮಬದ್ಧವಾಗಿ ದಾಖಲಿಸುವ ವಿಧಾನ.",
    subject: "Commerce",
    exampleSentence: "Accounting helps track business profit."
  },
  {
    id: 41,
    englishWord: "Consumer",
    kannadaMeaning: "ಗ್ರಾಹಕ / ಬಳಕೆದಾರ",
    explanation: "ವಸ್ತು ಅಥವಾ ಸೇವೆಯನ್ನು ಖರೀದಿಸಿ ಬಳಸುವ ವ್ಯಕ್ತಿ.",
    subject: "Commerce",
    exampleSentence: "The consumer is the king of the market."
  },
  {
    id: 42,
    englishWord: "Insurance",
    kannadaMeaning: "ವಿಮೆ",
    explanation: "ಭವಿಷ್ಯದ ನಷ್ಟಗಳನ್ನು ಸರಿದೂಗಿಸಲು ಮಾಡಿಕೊಳ್ಳುವ ಒಪ್ಪಂದ.",
    subject: "Commerce",
    exampleSentence: "Life insurance provides family security."
  },
  {
    id: 43,
    englishWord: "Revenue",
    kannadaMeaning: "ಆದಾಯ / ರಾಜಸ್ವ",
    explanation: "ವಸ್ತುಗಳನ್ನು ಮಾರಾಟ ಮಾಡುವುದರಿಂದ ಬರುವ ಒಟ್ಟು ಹಣ.",
    subject: "Commerce",
    exampleSentence: "The company reported high revenue this quarter."
  },
  {
    id: 44,
    englishWord: "Budget",
    kannadaMeaning: "ಅಂದಾಜು ಪಟ್ಟಿ",
    explanation: "ಭವಿಷ್ಯದ ಆದಾಯ ಮತ್ತು ವೆಚ್ಚಗಳ ಅಂದಾಜು ಯೋಜನೆ.",
    subject: "Commerce",
    exampleSentence: "Planning a budget saves money."
  },
  {
    id: 45,
    englishWord: "Marketing",
    kannadaMeaning: "ಮಾರುಕಟ್ಟೆ ಪ್ರಕ್ರಿಯೆ",
    explanation: "ವಸ್ತುಗಳನ್ನು ಜನರಿಗೆ ತಲುಪಿಸಲು ಮಾಡಲಾಗುವ ಪ್ರಚಾರ ಮತ್ತು ಮಾರಾಟ ತಂತ್ರಗಳು.",
    subject: "Commerce",
    exampleSentence: "Digital marketing is growing rapidly."
  },
  {
    id: 46,
    englishWord: "Entrepreneur",
    kannadaMeaning: "ಉದ್ಯಮಿ",
    explanation: "ಹೊಸ ವ್ಯವಹಾರವನ್ನು ಆರಂಭಿಸಿ ಅಪಾಯಗಳನ್ನು ಎದುರಿಸುವ ವ್ಯಕ್ತಿ.",
    subject: "Commerce",
    exampleSentence: "An entrepreneur creates new jobs."
  },
  {
    id: 47,
    englishWord: "Sustainability",
    kannadaMeaning: "ಸುಸ್ಥಿರತೆ",
    explanation: "ಪರಿಸರಕ್ಕೆ ಹಾನಿ ಮಾಡದೆ ದೀರ್ಘಕಾಲದವರೆಗೆ ಸಾಗುವ ಪ್ರಕ್ರಿಯೆ.",
    subject: "Commerce",
    exampleSentence: "Businesses should focus on sustainability."
  },
  {
    id: 48,
    englishWord: "Biodiversity",
    kannadaMeaning: "ಜೈವಿಕ ವೈವಿಧ್ಯತೆ",
    explanation: "ಒಂದು ಪ್ರದೇಶದಲ್ಲಿ ವಾಸಿಸುವ ವಿವಿಧ ರೀತಿಯ ಜೀವಿಗಳು.",
    subject: "Science",
    exampleSentence: "Forests are rich in biodiversity."
  },
  {
    id: 49,
    englishWord: "Theorem",
    kannadaMeaning: "ಪ್ರಮೇಯ",
    explanation: "ಗಣಿತದಲ್ಲಿ ತಾರ್ಕಿಕವಾಗಿ ಸಾಬೀತುಪಡಿಸಿದ ಹೇಳಿಕೆ.",
    subject: "Mathematics",
    exampleSentence: "Pythagoras theorem is very famous."
  },
  {
    id: 50,
    englishWord: "Equilibrium",
    kannadaMeaning: "ಸಮತೋಲನ",
    explanation: "ಎದುರು ಶಕ್ತಿಗಳು ಅಥವಾ ಪ್ರಭಾವಗಳು ಒಂದೇ ಸಮನಾಗಿ ಇರುವ ಸ್ಥಿತಿ.",
    subject: "Science",
    exampleSentence: "The liquid reached chemical equilibrium."
  },
  {
    id: 51,
    englishWord: "Prime Number",
    kannadaMeaning: "ಅವಿಭಾಜ್ಯ ಸಂಖ್ಯೆ",
    explanation: "೧ ಮತ್ತು ಅದೇ ಸಂಖ್ಯೆಯಿಂದ ಮಾತ್ರ ಭಾಗವಾಗುವ ಸಂಖ್ಯೆ.",
    subject: "Mathematics",
    exampleSentence: "Five is a prime number."
  },
  {
    id: 52,
    englishWord: "Taxation",
    kannadaMeaning: "ತೆರಿಗೆ ಪದ್ಧತಿ",
    explanation: "ಸಾರ್ವಜನಿಕ ವೆಚ್ಚಗಳಿಗಾಗಿ ಸರ್ಕಾರವು ವಿದಿಸುವ ಶುಲ್ಕ.",
    subject: "Commerce",
    exampleSentence: "Taxation funding public hospitals."
  }
];
