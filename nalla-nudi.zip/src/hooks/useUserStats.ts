import { useState, useEffect } from 'react';

export interface UserStats {
  xp: number;
  level: number;
  streak: number;
  lastActive: string | null;
  wordsLearned: number;
  badges: string[];
}

export function useUserStats() {
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('nalla_nudi_stats');
    return saved ? JSON.parse(saved) : {
      xp: 0,
      level: 1,
      streak: 0,
      lastActive: null,
      wordsLearned: 0,
      badges: []
    };
  });

  useEffect(() => {
    localStorage.setItem('nalla_nudi_stats', JSON.stringify(stats));
  }, [stats]);

  const addXP = (amount: number) => {
    setStats(prev => {
      const newXP = prev.xp + amount;
      const newLevel = Math.floor(newXP / 1000) + 1;
      
      const newBadges = [...prev.badges];
      if (newLevel > prev.level && !newBadges.includes('Level Up!')) {
        newBadges.push(`Level ${newLevel} Achiever`);
      }
      
      return { ...prev, xp: newXP, level: newLevel, badges: newBadges };
    });
  };

  const updateStreak = () => {
    const today = new Date().toDateString();
    setStats(prev => {
      if (prev.lastActive === today) return prev;
      
      const last = prev.lastActive ? new Date(prev.lastActive) : null;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      
      let newStreak = prev.streak;
      if (!last || last.toDateString() === yesterday.toDateString()) {
        newStreak += 1;
      } else {
        newStreak = 1;
      }

      return { ...prev, streak: newStreak, lastActive: today };
    });
  };

  const incrementWordsLearned = () => {
    setStats(prev => ({ ...prev, wordsLearned: prev.wordsLearned + 1 }));
  };

  return { stats, addXP, updateStreak, incrementWordsLearned };
}
